package com.example.aidrawingassistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent

class DrawingAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: DrawingAccessibilityService? = null }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* UI inspection can be added with user consent. */ }
    override fun onInterrupt() {}

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun drawDemoStroke() {
        val dm = resources.displayMetrics
        val x1 = dm.widthPixels * 0.35f
        val y1 = dm.heightPixels * 0.52f
        val x2 = dm.widthPixels * 0.65f
        val y2 = dm.heightPixels * 0.52f
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 650)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
