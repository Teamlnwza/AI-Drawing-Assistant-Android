package com.example.aidrawingassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "AI Drawing Assistant"
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            text = "รุ่นทดลอง: รับคำสั่งพื้นฐานและส่งท่าทางลากบนหน้าจอ ต้องเปิด Accessibility เอง"
            textSize = 14f
        })
        val accessibility = Button(this).apply {
            text = "1) เปิดการตั้งค่า Accessibility"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        layout.addView(accessibility)
        val overlay = Button(this).apply {
            text = "2) อนุญาตหน้าต่างลอย"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "อนุญาตแล้ว", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(overlay)
        val open = Button(this).apply {
            text = "3) เปิด ibisPaint X"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("jp.ne.ibis.ibispaintx.app")
                if (launch != null) startActivity(launch)
                else Toast.makeText(this@MainActivity, "ไม่พบ ibisPaint X", Toast.LENGTH_LONG).show()
            }
        }
        layout.addView(open)
        val command = EditText(this).apply {
            hint = "คำสั่งทดลอง เช่น ลากเส้นจากกลางจอไปทางขวา"
        }
        layout.addView(command)
        val run = Button(this).apply {
            text = "ทดลองลากเส้น 1 ครั้ง"
            setOnClickListener {
                val svc = DrawingAccessibilityService.instance
                if (svc == null) {
                    Toast.makeText(this@MainActivity, "กรุณาเปิด Accessibility Service ก่อน", Toast.LENGTH_LONG).show()
                } else {
                    // Demo coordinates are relative to the screen. Confirm ibisPaint canvas is visible first.
                    svc.drawDemoStroke()
                    Toast.makeText(this@MainActivity, "ส่งท่าทางลากแล้ว ตรวจสอบบนผืนผ้าใบ", Toast.LENGTH_SHORT).show()
                }
            }
        }
        layout.addView(run)
        layout.addView(TextView(this).apply {
            text = "ความปลอดภัย: ทดสอบบนผืนผ้าใบเปล่าก่อน การลากจะเกิดตรงพิกัดหน้าจอปัจจุบัน ไม่ได้รู้ขอบเขต Canvas อัตโนมัติ"
            textSize = 13f
        })
        setContentView(ScrollView(this).apply { addView(layout) })
    }
}
