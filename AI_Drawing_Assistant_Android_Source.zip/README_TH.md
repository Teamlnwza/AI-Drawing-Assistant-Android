# AI Drawing Assistant (Android) — รุ่นต้นแบบ 0.1

โปรเจกต์นี้เป็น **ซอร์สโค้ดต้นแบบ** สำหรับ Android ไม่ใช่ APK ที่คอมไพล์แล้ว และยังไม่ใช่ AI วาดภาพอัตโนมัติเต็มรูปแบบ

## ทำอะไรได้ในรุ่นนี้
- แสดงหน้าตั้งค่าเพื่อเปิด Accessibility Service
- เปิดหน้าต่างอนุญาต Overlay (ยังไม่ได้สร้างปุ่มลอยในรุ่นนี้)
- เปิด ibisPaint X หากติดตั้งไว้
- ส่งท่าทางลากเส้นสาธิตหนึ่งครั้งผ่าน Android Accessibility `dispatchGesture()`

## ข้อจำกัด
- พิกัดตัวอย่างเป็นพิกัดหน้าจอ ไม่ได้ตรวจจับขอบเขต Canvas หรือเลือกเครื่องมือใน ibisPaint ให้อัตโนมัติ
- ยังไม่มีการเชื่อม ChatGPT/Gemini/Claude API และไม่มีการส่งภาพไปยังบริการภายนอก
- อย่าใส่ API key ลงในแอปโดยตรง
- ทดสอบบนผืนผ้าใบเปล่าก่อน เพราะท่าทางลากจะเกิด ณ ตำแหน่งหน้าจอที่กำหนด
- Android/OEM อาจจำกัดการทำงานเบื้องหลัง ต้องอนุญาต Accessibility ด้วยตนเอง

## เครื่องมือที่ต้องใช้
- Android Studio
- JDK 17
- Android SDK Platform 35
- Gradle ที่ Android Studio ดาวน์โหลดให้

## วิธีเปิดและสร้าง APK
1. แตก ZIP
2. เปิด Android Studio > Open > เลือกโฟลเดอร์ `AIDrawingAssistant`
3. รอ Gradle Sync
4. ถ้าระบบขอ SDK Platform 35 ให้ติดตั้ง
5. เลือก Build > Build Bundle(s) / APK(s) > Build APK(s)
6. ไฟล์ debug APK จะอยู่ที่ `app/build/outputs/apk/debug/app-debug.apk`

## วิธีติดตั้งและทดลอง
1. ติดตั้ง APK บน iQOO Z9 5G
2. เปิดแอป แล้วกดปุ่มเปิด Accessibility Settings
3. เปิด `AI Drawing Assistant` ในรายการบริการ และยืนยันสิทธิ์
4. เปิด ibisPaint X แล้วสร้างผืนผ้าใบเปล่า
5. กลับแอปผู้ช่วย แล้วกดทดลองลากเส้น
6. ตรวจสอบผลบน Canvas

## ความเป็นส่วนตัว
รุ่นนี้ไม่ส่งภาพหรือคำสั่งออกอินเทอร์เน็ต และไม่มี API key
